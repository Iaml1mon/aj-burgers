
# AJ Burgers Website

This is the customized website for AJ Burgers, based on the Manila Crepes template.
Built with Vite, React, TypeScript, and TailwindCSS.

Live Deployment Coming Soon...
